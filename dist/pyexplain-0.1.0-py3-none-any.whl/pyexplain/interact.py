# from utils import *


# text  = """
# # Display utilities
# def highlight_code(code, language='python'):
#     lexer = get_lexer_by_name(language, stripall=True)
#     formatter = TerminalFormatter()
#     return highlight(code, lexer, formatter)


# def display_code(text:str):
#     console = Console()

#     text_to_display = highlight_code(text)
#     background_color = "#3C4142"  # Hex color code for the background

#     styled_text = f"[white on {background_color}] {text_to_display} [/white on {background_color}]"

#     console.print(styled_text)
# """

# interact = Interact()

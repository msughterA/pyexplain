from .utils import Interact


def main():
    interact = Interact()
    
    
if __name__ == '__main__':
    main()